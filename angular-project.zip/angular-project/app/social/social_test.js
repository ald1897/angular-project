'use strict';

describe('myApp.social module', function() {

  beforeEach(module('myApp.social'));

  describe('social controller', function(){

    it('should ....', inject(function($controller) {
      //spec body
      var view2Ctrl = $controller('socialCtrl');
      expect(view2Ctrl).toBeDefined();
    }));

  });
});